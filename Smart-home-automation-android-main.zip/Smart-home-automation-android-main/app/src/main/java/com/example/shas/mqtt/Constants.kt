package com.example.shas.mqtt



const val MQTT_SERVER_URI = "tcp://142.93.57.145:1883"


const val MQTT_TEST_TOPIC = "shas"
